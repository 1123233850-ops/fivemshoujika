-- 语言文件初始化
Locales = Locales or {}

